/* Consigna 1 */

SELECT TOP(3) upper(Nombre), Domicilio, Email FROM Clientes ORDER BY Nombre;

/* Consigna 2 */

SELECT Nombre, Precio_Unitario, idProveedor 
  FROM Articulos 
  WHERE Precio_Unitario>10 AND Precio_Unitario<100;

/* Consigna 3 */


	SELECT   Pro.Nombre, Email, Domicilio, Activo
	 FROM Proveedores Pro
     inner join Provincias on Pro.Provincia = Provincias.idProvincia
	 WHERE Pro.Nombre LIKE 'F%' AND Activo=1 AND Pais='Argentina';
	


/* Consigna 4 */

SELECT Fecha, Cliente, Descuento, Total 
  FROM Facturas 
  WHERE Descuento>0 OR Total<15000;

/* Consigna 5 */

UPDATE Provincias SET Pais='Argentina';

/* Consigna 6 */

UPDATE Articulos SET Stock_Actual=Stock_Actual+10 WHERE idRubro=1;

/* Consigna 7 */

UPDATE Articulos SET Precio_Unitario=Precio_unitario*1.2 WHERE idRubro=3 AND idProveedor=1;

/* Consigna 8 */

DELETE FROM Provincias WHERE Pais='Espa�a';

/* Consigna 9 */

DELETE FROM Facturas WHERE Cliente=3;

/* Consigna 10 */

INSERT INTO Rubros VALUES ('Indumentaria');

/* Consigna 11 */

INSERT INTO Provincias VALUES ('Canelones', 'Uruguay');

/* Consigna 12 */

INSERT INTO Clientes VALUES ('Pepe Monteros', 'Hector Miranda 245', 'pepemonteros@gmail.com', '6', '4');

/* Consigna 13 */

INSERT INTO Proveedores VALUES ('Arcor', 'Baltasar Brum 1564', 'consultas@arcor.com', '6', 'False');

/* Consigna 14 */

DELETE FROM Delivery WHERE idRepartidor=4;

SELECT TOP(5) Fecha_de_Nacimiento FROM Repartidores ORDER BY DNI desc;

INSERT INTO DetalleEnvios VALUES ('Auto', 'JAO 169', 'BMW', '2021-06-01');